#ifndef SCORES_H
#define SCORES_H

struct Scores
{
    int trns;
    int cmbHi;
};

#endif
